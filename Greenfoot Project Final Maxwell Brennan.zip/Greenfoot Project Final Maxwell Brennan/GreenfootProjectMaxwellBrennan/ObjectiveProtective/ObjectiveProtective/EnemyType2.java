import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyType2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyType2 extends Actor
{
    private int changeDirectionTimer = 0;
    private boolean ready = false;
    private int timeBeforeReady = 50;
    public void act()
    {
        if (!ready)
            {
                timeBeforeReady--;

                if (timeBeforeReady <= 0)
                {
                    ready = true;
                    setImage("enemy2.png");
                }

                return;
            }       
        randomOrChase();
    }

    private void randomOrChase()
    {
        
        if (Greenfoot.getRandomNumber(10) < 1)
        {
            chase();
            setImage("enemy2.png");
        }
        else
        {
            randomMovement();
            setImage("enemy2stupid.png");
        }
    }

    private void randomMovement()
    {
        if (changeDirectionTimer <= 0)
        {
            int turnAmount = Greenfoot.getRandomNumber(90) - 45;
            turn(turnAmount);
            changeDirectionTimer = Greenfoot.getRandomNumber(30) + 10;
        }
        else
        {
            changeDirectionTimer--;
        }

        move(2);
            if (isTouching(Wall.class))
        {
            move(-2);
        }
            if (isTouching(FakeWall.class))
        {
            move(-2);
        }
    }

    private void chase()
    {
        if (!getWorld().getObjects(ProtectObject.class).isEmpty())
        {
            ProtectObject p = (ProtectObject)getWorld().getObjects(ProtectObject.class).get(0);

            turnTowards(p.getX(), p.getY());
            move(4);
        }
    }
}
