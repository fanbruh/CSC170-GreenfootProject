import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Scoreboard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboard extends Actor
{
    private int score = 10;

    public Scoreboard()
    {
        updateImage();
    }

    public void addScore(int points)
    {
        score += points;
        updateImage();
        if (score < 0){
        Greenfoot.stop();
        Greenfoot.playSound("loser.wav");
        WinOrLose winorlose = new WinOrLose();
            getWorld().addObject(winorlose, 300, 200);
            winorlose.lose();
    }
    }

    public int getScore()
    {
        return score;
    }

    private void updateImage()
    {
        setImage(new GreenfootImage("Score: "+score,24,Color.GREEN,Color.WHITE));
    }
}
