import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ProtectObject here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProtectObject extends Actor
{
    public void act()
    {
        move(5);
        randomTurn();
        checkEdge();
        touchingEnemies();
    }

    private void randomTurn()
    {
        if (Greenfoot.getRandomNumber(100) < 10)
        {
            turn(Greenfoot.getRandomNumber(90) - 45);
        }
    }

    private void checkEdge()
    {
        if (isAtEdge())
        {
            turn(180);
        }
    }
    private void touchingEnemies()
    {
        if (isTouching(EnemyType1.class))
    {
        removeTouching(EnemyType1.class);
        hurt();
    }

    if (isTouching(EnemyType2.class))
    {
        removeTouching(EnemyType2.class);
        hurt();
    }

    if (isTouching(FakeWall.class))
    {
        removeTouching(FakeWall.class);
        hurt();
    }
    }
    private void hurt()
    {
        Greenfoot.playSound("gottem.wav");
        getWorld().getObjects(Scoreboard.class).get(0).addScore(-1);
    }
}
