import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyType3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyType3 extends Actor
{
    /**
     * Act - do whatever the EnemyType3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private boolean ready = false;
    private int timeBeforeReady = 50;
    public void act()
    {
        if (!ready)
            {
                timeBeforeReady--;

                if (timeBeforeReady <= 50)
                {
                    ready = true;
                    setImage("enemy3.png");
                }
                
                

                return;
            }
        movement();
        move(2);
        timeBeforeReady--;
        if (timeBeforeReady <= -100)
            {
                getWorld().removeObject(this);
                return;
            }
            if (isTouching(Wall.class))
        {
            move(-2);
        }
            if (isTouching(FakeWall.class))
        {
            move(-2);
        }
    }

    private void movement()
    {
        Player player = (Player)getWorld().getObjects(Player.class).get(0);

        if (player != null)
        {
            turnTowards(player.getX(), player.getY());
        }
    }
}
