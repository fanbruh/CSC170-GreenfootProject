import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WinOrLose here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WinOrLose extends Actor
{
    /**
     * Act - do whatever the WinOrLose wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private boolean gameover = false;

    public void win()
    {
        if (!gameover)
        {
            setImage("win.png");
            gameover = true;
            Greenfoot.stop();
        }
    }

    public void lose()
    {
        if (!gameover)
        {
            setImage("lose.png");
            gameover = true;
            Greenfoot.stop();
        }
    }
}
