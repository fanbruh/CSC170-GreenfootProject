import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        playerMovement();
        collision();
    }
    public void playerMovement()
    {
        if (Greenfoot.isKeyDown("w"))
        {
            move(5);
            if (isTouching(Wall.class))
        {
            move(-6);
        }
        }
        if (Greenfoot.isKeyDown("a"))
        {
            turn(-5);
        }
        if (Greenfoot.isKeyDown("d"))
        {
            turn(5);
        }
    }
    public void collision()
    {
        Actor enemy1 = getOneIntersectingObject(EnemyType1.class);
        Actor enemy2 = getOneIntersectingObject(EnemyType2.class);
        Actor enemy3 = getOneIntersectingObject(EnemyType3.class);
        Actor fakewall = getOneIntersectingObject(FakeWall.class);
        if (enemy1 != null)
        {
            getWorld().removeObject(enemy1);
            Greenfoot.playSound("point.wav");
            getWorld().getObjects(Scoreboard.class).get(0).addScore(1);
        }
        if (enemy2 != null)
        {
            getWorld().removeObject(enemy2);
            Greenfoot.playSound("point.wav");
            getWorld().getObjects(Scoreboard.class).get(0).addScore(1);
        }
        if (enemy3 != null)
        {
            getWorld().getObjects(Scoreboard.class).get(0).addScore(-1);
            getWorld().removeObject(enemy3);
            Greenfoot.playSound("gottem.wav");
        }
        if (fakewall != null)
        {
            getWorld().removeObject(fakewall);
            Greenfoot.playSound("point.wav");
            getWorld().getObjects(Scoreboard.class).get(0).addScore(1);
        }
    }
}
    
