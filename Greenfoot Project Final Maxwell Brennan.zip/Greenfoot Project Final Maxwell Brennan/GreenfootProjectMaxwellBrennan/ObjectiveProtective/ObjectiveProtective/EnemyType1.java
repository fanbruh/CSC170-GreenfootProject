import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyType1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyType1 extends Actor
{
    /**
     * Act - do whatever the EnemyType1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private boolean ready = false;
    private int timeBeforeReady = 50;
    public void act()
    {
        if (!ready)
            {
                timeBeforeReady--;

                if (timeBeforeReady <= 0)
                {
                    ready = true;
                    setImage("enemy1.png"); // switch to real sprite
                }

                return;
            }       

        movement();
        move(2);
            if (isTouching(Wall.class))
        {
            move(-2);
        }
            if (isTouching(FakeWall.class))
        {
            move(-2);
        }
    }
    private void movement()
    {
        ProtectObject protectobject = (ProtectObject)getWorld().getObjects(ProtectObject.class).get(0);

        if (protectobject != null)
        {
            turnTowards(protectobject.getX(), protectobject.getY());
        }
    }
}
