import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ObjectiveProtective extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public ObjectiveProtective()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    public void act()
    {
    enemySpawn();
    wallSpawn();
    }
    public void prepare()
    {
        Player player = new Player();
        addObject(player, 300, 200);
        ProtectObject protectobject = new ProtectObject();
        addObject(protectobject, 300, 100);
        Timer timer = new Timer();
        addObject (timer, 500, 25);
        Scoreboard scoreboard = new Scoreboard();
        addObject(scoreboard, 100, 25);
        
    }
    public void enemySpawn()
{
    int enemyNumber = getObjects(EnemyType1.class).size()
              + getObjects(EnemyType2.class).size()
              + getObjects(EnemyType3.class).size();
    if (enemyNumber < 3)
    {
        int whichEnemy = Greenfoot.getRandomNumber(3);
        if (whichEnemy == 0)
        {
            addObject(new EnemyType1(), Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(400));
        }
        else if (whichEnemy == 1)
        {
            addObject(new EnemyType2(), Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(400));
        }
        else
        {
            addObject(new EnemyType3(), Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(400));
        }
    }
}
    public void wallSpawn()
{
    int wallNumber = getObjects(Wall.class).size()
              + getObjects(FakeWall.class).size();
    if (wallNumber < 3)
    {
        int whichWall = Greenfoot.getRandomNumber(2);
        if (whichWall == 0)
        {
            addObject(new Wall(), Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(400));
        }
        else
        {
            addObject(new FakeWall(), Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(400));
        }
    }
}
}
