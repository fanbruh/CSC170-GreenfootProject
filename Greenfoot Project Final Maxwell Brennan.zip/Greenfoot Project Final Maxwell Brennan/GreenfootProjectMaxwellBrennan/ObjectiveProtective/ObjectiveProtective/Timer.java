import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Timer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer extends Actor
{
    private int frames = 0;
    private int seconds = 0;
    private int minutes = 1;

    public Timer()
    {
        updateImage();
    }

    public void act()
    {
        frames--;

        if (frames<0)
        {
            frames = 59;
            seconds--;
        }

        if (seconds<0)
        {
            seconds = 59;
            minutes--;
        }
        if (minutes<0)
        {
            Greenfoot.stop();
            Greenfoot.playSound("youdidit.wav");
            WinOrLose winorlose = new WinOrLose();
            getWorld().addObject(winorlose, 300, 200);
            winorlose.win();
            minutes = 0;
            seconds = 0;
            frames = 0;
        }

        updateImage();
    }

    private void updateImage()
    {
        
        setImage(new GreenfootImage("TIME: "+minutes+"m:"+seconds+"s:"+frames+"f", 24, Color.RED, Color.WHITE));
    }
}
