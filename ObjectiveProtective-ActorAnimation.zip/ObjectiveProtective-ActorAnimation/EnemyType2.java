import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyType2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyType2 extends Actor
{
    private int changeDirectionTimer = 0;

    public void act()
    {
        randomOrChase();
    }

    private void randomOrChase()
    {
        
        if (Greenfoot.getRandomNumber(100) < 2)
        {
            chase();
        }
        else
        {
            randomMovement();
        }
    }

    private void randomMovement()
    {
        // Change direction sometimes
        if (changeDirectionTimer <= 0)
        {
            int turnAmount = Greenfoot.getRandomNumber(90) - 45; // -45 to +45
            turn(turnAmount);
            changeDirectionTimer = Greenfoot.getRandomNumber(30) + 10;
        }
        else
        {
            changeDirectionTimer--;
        }

        move(2);
    }

    private void chase()
    {
        if (!getWorld().getObjects(ProtectObject.class).isEmpty())
        {
            ProtectObject p = (ProtectObject)getWorld().getObjects(ProtectObject.class).get(0);

            turnTowards(p.getX(), p.getY());
            move(4);
        }
    }
}
