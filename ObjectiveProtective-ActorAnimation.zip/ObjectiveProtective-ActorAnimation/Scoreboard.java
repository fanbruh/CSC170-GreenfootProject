import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Scoreboard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboard extends Actor
{
    private int score = 0;

    public Scoreboard()
    {
        updateImage();
    }

    public void addScore(int points)
    {
        score += points;
        updateImage();
    }

    public int getScore()
    {
        return score;
    }

    private void updateImage()
    {
        setImage(new GreenfootImage("Score: "+score,24,Color.GREEN,Color.WHITE));
    }
}
