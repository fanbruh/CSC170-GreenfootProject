import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FakeWall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FakeWall extends Actor
{
    /**
     * Act - do whatever the FakeWall wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        ProtectObject protectobject = (ProtectObject)getWorld().getObjects(ProtectObject.class).get(0);

        if (protectobject != null)
        {
            turnTowards(protectobject.getX(), protectobject.getY());
        }
        move(1);
    }
}
