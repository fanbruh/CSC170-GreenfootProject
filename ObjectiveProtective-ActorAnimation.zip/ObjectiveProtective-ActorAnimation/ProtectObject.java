import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ProtectObject here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProtectObject extends Actor
{
    public void act()
    {
        move(5);
        randomTurn();
        checkEdge();
    }

    private void randomTurn()
    {
        // Small chance to turn each frame
        if (Greenfoot.getRandomNumber(100) < 10)
        {
            turn(Greenfoot.getRandomNumber(90) - 45); // turn between -45 and +45
        }
    }

    private void checkEdge()
    {
        if (isAtEdge())
        {
            turn(180); // bounce back
        }
    }
}
