import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyType3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyType3 extends Actor
{
    /**
     * Act - do whatever the EnemyType3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        movement();
        move(2);
    }

    private void movement()
    {
        Player player = (Player)getWorld().getObjects(Player.class).get(0);

        if (player != null)
        {
            turnTowards(player.getX(), player.getY());
        }
    }
}
