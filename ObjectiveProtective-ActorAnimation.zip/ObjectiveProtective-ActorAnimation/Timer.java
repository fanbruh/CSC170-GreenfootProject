import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Timer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer extends Actor
{
    private int frames = 0;
    private int seconds = 0;
    private int minutes = 0;

    public Timer()
    {
        updateImage();
    }

    public void act()
    {
        frames++;

        if (frames >= 60)
        {
            frames = 0;
            seconds++;
        }

        if (seconds >= 60)
        {
            seconds = 0;
            minutes++;
        }

        updateImage();
    }

    private void updateImage()
    {
        
        setImage(new GreenfootImage("TIME: "+minutes+"m:"+seconds+"s:"+frames+"f", 24, Color.RED, Color.WHITE));
    }
}
