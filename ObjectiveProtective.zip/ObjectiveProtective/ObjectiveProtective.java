import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ObjectiveProtective extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public ObjectiveProtective()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    public void prepare()
    {
        Player player = new Player();
        addObject(player, 100, 100);
        EnemyType1 enemytype1 = new EnemyType1();
        addObject(enemytype1, 200, 100);
        EnemyType2 enemytype2 = new EnemyType2();
        addObject(enemytype2, 300, 100);
        EnemyType3 enemytype3 = new EnemyType3();
        addObject(enemytype3, 400, 100);
        Wall wall = new Wall();
        addObject(wall, 500, 100);
        Level level = new Level();
        addObject(level, 50, 50);
        ProtectObject protectobject = new ProtectObject();
        addObject(protectobject, 100, 200);
        Timer timer = new Timer();
        addObject (timer, 550, 50);
    }
}
